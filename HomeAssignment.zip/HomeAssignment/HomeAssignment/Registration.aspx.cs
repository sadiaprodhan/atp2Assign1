﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace HomeAssignment
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\iliana\documents\visual studio 2012\Projects\HomeAssignment\HomeAssignment\App_Data\assignment.mdf;Integrated Security=True");

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd= con.CreateCommand();
            cmd.CommandType= System.Data.CommandType.Text;
            cmd.CommandText = "insert into users values ("+tbId.Text +", '"+tbPass.Text +"', '"+tbName.Text +"', '"+tbEmail.Text +"')";
            if(cmd.ExecuteNonQuery() ==1)
            Response.Redirect("login.aspx");
            con.Close();
        
        }
    }
}