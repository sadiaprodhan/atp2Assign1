﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace HomeAssignment
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\iliana\documents\visual studio 2012\Projects\HomeAssignment\HomeAssignment\App_Data\assignment.mdf;Integrated Security=True");

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from users where id=" + tbId.Text + " and password= '" + tbPass.Text + "'", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                lbl.Text = "id passsword matched";

            }
            else
            { lbl.Text = "id pass doesn't match"; }
              con.Close();
        

        }
    }
}